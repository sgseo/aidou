<?php
namespace app\index\controller;

use think\Controller;
use think\Session;

class Moneylog extends Controller{
    public function  list(){
        return view();
    }
    
}