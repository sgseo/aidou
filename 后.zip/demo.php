<?php
beast_encode_file('./pay.php','./pay2.php',0,BEAST_ENCRYPT_TYPE_DES);